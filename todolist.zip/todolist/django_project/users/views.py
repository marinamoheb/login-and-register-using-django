from django.contrib.auth.views import LoginView
from django.views.generic import TemplateView,FormView
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from . forms import RegistrationForm
# users/views.py
from django.contrib.auth import login
from django.contrib import messages
from django

class HomeView(TemplateView):
    template_name = 'home.html'

class ProfileView(LoginRequiredMixin,TemplateView):
    template_name = 'profile.html'

    
    
class MyLoginView(LoginView):
    redirect_authenticated_user =True
    # template_name = 'registration/login.html'
    
    def get_success_url(self):
        messages.info(self.request,"welcome to your profile")
        return reverse_lazy('profile')
    def form_invalid(self,form):
        messages.error(self.request, "Invalid username or password")
        return self.render_to_response(self.get_context_data(form=form))
    
    
class RegisterView(FormView):
    form_class = RegistrationForm
    redirect_authenticated_user =True
    success_url=reverse_lazy('profile') 
    template_name = 'registration/register.html'
    def form_valid(self,form):
        user= form.save()
        if user:
            login(self.request,user)
        return super(RegisterView,self).form_valid(form)